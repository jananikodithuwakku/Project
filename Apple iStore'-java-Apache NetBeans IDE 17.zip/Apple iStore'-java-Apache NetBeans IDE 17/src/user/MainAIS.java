package user;
import business.Cashier;
import business.Category;
import business.Manager;
import business.Product;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MainAIS {

    public static void main(String args[]) {
        ArrayList<Product> products = new ArrayList<>();
        ArrayList<Category> categories = new ArrayList<>();

        // Adding sample categories
        categories.add(new Category("iPhone"));
        categories.add(new Category("Apple Watch"));
        categories.add(new Category("iPad"));

        // Adding sample products to the system
        products.add(new Product("iPhone 13",001, "iPhone", 999.99, 50));
        products.add(new Product("Apple Watch Series 7",002,"Apple Watch", 399.99, 30));
        products.add(new Product("iPad Pro",003, "iPad", 799.99, 20));

        // Creating a Cashier and Manager
        Cashier cashier = new Cashier("cashier1", "password");
        Manager manager = new Manager("manager1", "password");

        // Cashier views all products
        cashier.viewProducts(products);

        // Cashier searches for products based on search criteria
        cashier.searchStock(products, "iPhone");

        // Manager adds a new product
        manager.addProduct(products, "AirPods Pro",004, "i Phone", 249.99, 100);

        // Cashier views all products again (including the new one added by the manager)
        cashier.viewProducts(products);
    }
    private void initComponents(){
        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel employeeIDLabel = new JLabel("Employee ID:");
        JLabel accountTypeLabel = new JLabel("Account Type:");

    }
}
    

