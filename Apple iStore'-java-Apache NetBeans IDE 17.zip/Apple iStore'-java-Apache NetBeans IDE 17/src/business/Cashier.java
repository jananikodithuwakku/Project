package business;

import java.util.ArrayList;

public class Cashier extends Account {

    private String CashierName;
    private String Password;

    public Cashier(String CashierName, String Password) {
        super(CashierName, Password, "Cashier");
    }

    public String getCashierName() {
        return CashierName;
    }

    public String getPassword() {
        return Password;
    }

    public void setCashierName(String CashierName) {
        this.CashierName = CashierName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void viewProducts(ArrayList<Product> products) {
        // Implementation to view all products
        for (Product product : products) {
            System.out.println("Name: " + product.getName());
            System.out.println("ProductID:" + product.getProductID());
            System.out.println("Category: " + product.getCategory());
            System.out.println("Price: $" + product.getPrice());
            System.out.println("Stock: " + product.getStock());
            System.out.println("-----------------------");
        }
    }

    public void searchStock(ArrayList<Product> products, String searchCriteria) {
        // Implementation to search for stock details based on searchCriteria (e.g., category, name, price)
        // Implementation omitted for simplicity
    }

    public boolean userVerification2(String cashier, String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
