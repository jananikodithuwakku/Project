package business;

import java.util.ArrayList;

public class Manager extends Account {

    private String ManagerName;
    private String Password;

    public Manager(String ManagerName, String Password) {
        super(ManagerName, Password, "Manager");
    }

    public String getManagerName() {
        return ManagerName;
    }

    public String getPassword() {
        return Password;
    }

    public void setManagerName(String ManagerName) {
        this.ManagerName = ManagerName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void createAccount(String username, String password, String accountType) {
        // Implementation to create a new account
        // Implementation omitted for simplicity
    }

    public void addProduct(ArrayList<Product> products, String name, int ProductID, String Category, double price, int stock) {
        // Implementation to add a new product to the system
        Product newProduct = new Product(name, ProductID, Category, price, stock);
        products.add(newProduct);
    }

}
