package business;

public class Account {

    private String userName;
    private String Password;
    private String AccountType;

    public Account(String userName, String Password, String AccountType) {
        this.userName = userName;
        this.Password = Password;
        this.AccountType = AccountType;
    }

    public String getuserName() {
        return userName;
    }

    public String getPassword() {
        return Password;
    }

    public String getAccountType() {
        return AccountType;
    }

    public void setuserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

}
