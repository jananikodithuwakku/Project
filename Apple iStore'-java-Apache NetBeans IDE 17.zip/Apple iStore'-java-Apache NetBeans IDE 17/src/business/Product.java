package business;

public class Product {

    private String Name;
    private int ProductID;
    private String Category;
    private double Price;
    private int Stock;

    public Product() {

    }

    public Product(String Name,int ProductID, String Category, double Price, int Stock) {
        this.Name = Name;
        this.ProductID = ProductID;
        this.Category = Category;
        this.Price = Price;
        this.Stock = Stock;
    }

    

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

}
