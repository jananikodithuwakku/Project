package data;

import java.util.ArrayList;
import business.Product;

public class ProductAIS {

    private final ArrayList<Product> pList;

    public ProductAIS() {
        pList = new ArrayList<>();
    }

    public boolean add(Product p) {
        return pList.add(p);
    }

    public Product get(int pID) {
        for (Product p : pList) {
            if (p.getProductID() == pID) {
                return p;
            }
        }
        return null;
    }

    public ArrayList<Product> getAll() {
        return pList;
    }
}
