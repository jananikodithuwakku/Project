
package data;
import business.Manager;

public class ManagerLogin {
    public boolean userVerification(Manager user) {

        if (user.getManagerName() == "Manager" && user.getPassword() == "2010") {
            return true;
        } else {
            return false;
        }

    }
    
    public boolean userVerification2(String user, String user2) {

        if (user == "Manager" && user2 == "2010") {
            return true;
        } else {
            return false;
        }

    }

}
