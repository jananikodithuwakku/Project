
package data;
import java.util.ArrayList;
import business.Account;

public class AccountAIS {
    private final ArrayList<Account> aList;
            
    public AccountAIS() {
        aList=new ArrayList<>();
    }
    
    public boolean add(Account a){
        return aList.add(a);       
    }
    
    public Account get(String aAccountType){
        for(Account a:aList){
            if(a.getAccountType().equals(aAccountType)){
                return a;
            }
        }
        return null;
    }
    public ArrayList<Account> getAll(){
        return aList;
    }
}
