
package data;
import business.Cashier;

public class CashierLogin {
    public boolean userVerification(Cashier user) {

        if (user.getCashierName() == "Cashier" && user.getPassword() == "1020") {
            return true;
        } else {
            return false;
        }

    }
    
    public boolean userVerification2(String user, String user2) {

        if (user == "Cachier" && user2 == "1020") {
            return true;
        } else {
            return false;
        }

    }

}


