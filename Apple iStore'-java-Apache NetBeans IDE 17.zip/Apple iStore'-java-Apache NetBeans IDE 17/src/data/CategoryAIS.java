package data;

import java.util.ArrayList;
import business.Category;

public class CategoryAIS {

    private final ArrayList<Category> cList;

    public CategoryAIS() {
        cList = new ArrayList<>();
    }

    public boolean add(Category c) {
        return cList.add(c);
    }

    public Category get(String cCategoryName) {
        for (Category c : cList) {
            if (c.getCategoryName().equals(cCategoryName)) {
                return c;
            }
        }
        return null;
    }

    public ArrayList<Category> getAll() {
        return cList;
    }
}
