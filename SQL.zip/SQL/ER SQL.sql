--drop table StudentD
--drop table BatchD
--drop table EmployeeD
--drop table ProgramD
--drop table ModulD
--drop table StudentQualificationD
--drop table DepartmentD
--drop table ModuleLeaderD
--drop table StudentCouncilorD
--drop table Student_Program_StudentCouncilorD
--drop table Program_ModuleD
--drop table Student_BatchD

create table StudentD
(
NIC int primary key not null ,
FName varchar(50)Not Null,
LName varchar(50),
PNo varchar(20),
Email varchar(60),
PostCode varchar(30),
City varchar (30),
)

create table BatchD
(
ENo varchar (12) not null unique ,
BNo varchar(12) not null unique ,
StartDate date,
EndDate date ,
NoOfStudents int
Constraint PK_BatchD Primary Key(BNo),
Constraint FK_BatchD Foreign key (ENo) References EmployeeD (ENo)
)

create table ProgramD
(
ProID int primary key not null ,
ProName varchar (100),
ProType varchar (20),
Duration int, --duration in months
paymentAmount decimal(10,2)
)

create table ModuleD
(
ENo varchar (12)not null unique,
ModuleNo varchar(12),
ModuleName varchar (100)Not null Unique,
CreditValue int,
NoOfSessions int,
Constraint PK_ModuleD Primary Key(ModuleNo),
Constraint FK_ModuleD Foreign key (ENo) References EmployeeD (ENo)
)

Create table StudentQualificationD
(
NIC int,
Qualification varchar (100)
Constraint FK_StudentQualificationD Foreign Key (NIC)References StudentD (NIC)
)

create table DepartmentD
(
DepID varchar(15)not null unique,
DepartmentName varchar(150),
Constraint PK_DepartmentD Primary Key (DepID)
)

create table EmployeeD
(
DepID varchar(15),
ENo varchar(12)not null unique,
EmpName varchar(100),
Email varchar(100),
ContactNo varchar(20),
Constraint PK_EmployeeD Primary Key(ENo),
Constraint FK_EmployeeD Foreign Key (DepID)References DepartmentD (DepID)
)

create table StudentCouncilorD
(
ENo varchar(12),
Constraint PK_StudentCouncilorD Primary Key(ENo),
Constraint FK_StudentCouncilorD Foreign Key (ENo)References EmployeeD (ENo)
)

create table ModuleLeaderD
(
ENo varchar(12),
Constraint PK_ModuleLeaderD Primary Key(ENo),
Constraint FK_ModuleLeaderD Foreign Key (ENo)References EmployeeD (ENo)
)

create table Student_Program_StudentCouncilorD
(
NIC int ,
ProID int ,
ENo varchar(12),
ReNo varchar (12),
Constraint PK_Student_Program_StudentCouncilorD Primary Key(NIC,ProID,ENo),
Constraint FK1_Student_Program_StudentCouncilorD Foreign Key (NIC)References StudentD (NIC),
Constraint FK2_Student_Program_StudentCouncilorD Foreign Key (ProID)References ProgramD (ProID),
Constraint FK3_Student_Program_StudentCouncilorD Foreign Key (ENo)References EmployeeD (ENo)
)

create table Student_BatchD
(
NIC int,
BNo varchar(12),
Constraint PK_Student_BatchD Primary Key(NIC,BNo),
Constraint FK1_Student_BatchD Foreign Key (NIC)References StudentD (NIC),
Constraint FK2_Student_BatchD Foreign Key (BNo)References BatchD (BNo)
)

create table Program_ModuleD
(
ProID int,
ModuleNo varchar(12),
Constraint PK_Program_ModuleD Primary Key(ProID,MOduleNo),
Constraint FK1_Program_ModuleD Foreign Key (ProID)References ProgramD (ProID),
Constraint FK2_Program_ModuleD Foreign Key (ModuleNo)References ModuleD  (ModuleNo)
)


Insert Into StudentD Values (200044475,'Janani','Kodithuwakku','0715269854','Janani@gmail.com','2017','Kandy')
Insert Into StudentD Values (452846252,'Sakuni','Weerasinha','0775885695','Sakuni@gmail.com','2014','Peradeniya')
Insert Into StudentD Values (561069884,'Nimasha','Bandara','0562314586','Nimasha@gmail.com','8562','Daulagala')
Insert Into StudentD Values (256546385,'Chethana','Hewage','0752362458','Chethana@gmail.com','7584','Bandarawela')
Insert Into StudentD Values (201359865,'Parami','Attanayaka','0775632149','Parami@gmail.com','2231','Nuwaraeliya')
Insert Into StudentD Values (889644475,'Dulmini','Abayakoon','0768652144','Dulmini@gmail.com','2310','Waththegama')
Insert Into StudentD Values (681235475,'Kaveesha','Disanayaka','0745586532','Kaveesha@gmail.com','1025','Katugasthota')
Insert Into StudentD Values (265989896,'Kasuni','Rathnayaka','0717856985','Kasuni@gmail.com','2014','Mathale')
Insert Into StudentD Values (892011666,'Supun','Perera','0723575896','Supun@gmail.com','7854','Mathara')
Insert Into StudentD Values (568963154,'Kamal','Herath','0775236148','Kamal@gmail.com','1203','Kurunagala')
Insert Into StudentD Values (798533457,'Nimal','Devid','0718569214','Nimal@gmail.com','7541','Kandy')
Insert Into StudentD Values (895632145,'Sachini','Dandeniya','0762512304','Sachini@gmail.com','3201','Mawanalla')
Insert Into StudentD Values (456683312,'Nipunsala','Denagamage','0785692145','Nipunsala@gmail.com','8652','Colombo')
Insert Into StudentD Values (568965647,'Nishantha','Dias','0718569214','Nishantha@gmail.com','2301','Jaffna')
Insert Into StudentD Values (568942102,'Lavan','Withanage','0715848524','Lavan@gmail.com','3201','Gampaha')

select*from StudentD

Insert Into StudentQualificationD Values(200044475,'Complete Advance Level')
Insert Into StudentQualificationD Values(452846252,'Bachelor of Science')
Insert Into StudentQualificationD Values(561069884,'Master of Business Administration')
Insert Into StudentQualificationD Values(256546385,'Diploma in IT')
Insert Into StudentQualificationD Values(201359865,'Diploma in business management')
Insert Into StudentQualificationD Values(889644475,'Diploma in english')
Insert Into StudentQualificationD Values(681235475,'Diploma in physiological')
Insert Into StudentQualificationD Values(265989896,'Bachelor of business management')
Insert Into StudentQualificationD Values(892011666,'Master of science')
Insert Into StudentQualificationD Values(568963154,'Diploma in IT')
Insert Into StudentQualificationD Values(798533457,'Complete Advance Level and Diploma in english')
Insert Into StudentQualificationD Values(895632145,'Diploma in tourism management')
Insert Into StudentQualificationD Values(456683312,'Diploma in IT and english')
Insert Into StudentQualificationD Values(568965647,'Bachelor of information technology')
Insert Into StudentQualificationD Values(568942102,'Master of information technology')

select*from StudentQualificationD

Insert Into BatchD Values('E012','B010','2023-01-01','2024-01-01',60)
Insert Into BatchD Values('E521','B012','2023-01-01','2025-01-01',70)
Insert Into BatchD Values('E623','B014','2023-02-01','2024-02-01',75)
Insert Into BatchD Values('E052','B016','2023-01-01','2024-06-01',65)
Insert Into BatchD Values('E002','B018','2023-04-01','2023-10-01',45)
Insert Into BatchD Values('E015','B020','2023-01-01','2025-06-01',50)
Insert Into BatchD Values('E152','B022','2023-03-01','2024-03-01',80)
Insert Into BatchD Values('E320','B023','2023-05-10','2023-11-01',95)
Insert Into BatchD Values('E624','B024','2023-03-01','2025-01-01',65)
Insert Into BatchD Values('E112','B026','2023-06-20','2025-01-20',70)
Insert Into BatchD Values('E017','B028','2023-05-05','2024-05-05',75)
Insert Into BatchD Values('E051','B030','2023-07-10','2025-07-10',85)
Insert Into BatchD Values('E070','B032','2023-01-01','2026-01-01',90)
Insert Into BatchD Values('E035','B034','2023-08-01','2026-08-01',50)
Insert Into BatchD Values('E201','B036','2023-07-01','2024-07-01',65)

select*from BatchD

Insert Into ProgramD Values (01,'Higher National Diploma in Business','Full Time',24,200000)
Insert Into ProgramD Values (02,'Higher National Diploma in Software Engineering','Full Time',24,290000)
Insert Into ProgramD Values (03,'Higher National Diploma in science network engineering','Part Time',24,250000)
Insert Into ProgramD Values (04,'Diploma in IT','Full Time',6,20000)
Insert Into ProgramD Values (05,'Diploma in English','Full Time',6,15000)
Insert Into ProgramD Values (06,'Higher National Diploma in human resource management ','Full Time',24,270000)
Insert Into ProgramD Values (07,'Higher National Diploma in Telecommunication & electronics engineering','Part Time',24,300000)
Insert Into ProgramD Values (08,'Bachelor of Science in Computer Science','Full Time',36,400000)
Insert Into Programd Values (09,'Bachelor of Information Technology','Part Time',36,3500000)
Insert Into ProgramD Values (10,'Bachelor of Technology in Software Technology','Full Time',36,370000)
Insert Into ProgramD Values (11,'Bachelor of Business Management','Full Time',36,320000)
Insert Into ProgramD Values (12,'Master of Science in Computer Science','Part Time',18,150000)
Insert Into ProgramD Values (13,'Master of Information Technology','Part Time',18,100000)
Insert Into ProgramD Values (14,'Master of Technology in Software Technology','Part Time',18,170000)
Insert Into ProgramD Values (15,'Master of Business Management','Part Time',18,100000)

select*from ProgramD

Insert Into ModuleD Values('E012','M001','Database Management Systems',36,15)
Insert Into ModuleD Values('E521','M002','Business Infromation Systems',36,14)
Insert Into ModuleD Values('E623','M003','Computer Networking',60,15)
Insert Into ModuleD Values('E052','M004','Object Oriented Programming',60,15)
Insert Into ModuleD Values('E002','M005','Professional Practice',50,15)
Insert Into ModuleD Values('E015','M006','Business Economics',30,16)
Insert Into ModuleD Values('E152','M007','Enterprise Project and Skills',35,18)
Insert Into ModuleD Values('E320','M008','Managing Systems and Operations',40,13)
Insert Into ModuleD Values('E624','M009','Organisational Behaviour and Human Resource Management',60,17)
Insert Into ModuleD Values('E112','M010','Marketing Principles',36,15)
Insert Into ModuleD Values('E017','M011','Foundations of Programming for Computer Science.',40,15)
Insert Into ModuleD Values('E051','M012','Mathematical Foundations of Computer Science',60,17)
Insert Into ModuleD Values('E070','M013','Human-Computer Interaction',36,16)
Insert Into ModuleD Values('E035','M014','Object-Oriented Data Structures and Algorithms',40,18)
Insert Into ModuleD Values('E201','M015','Introduction to Computer Architectures.',60,15)

select*from Moduled

Insert Into DepartmentD Values('D01','Research Department')
Insert Into DepartmentD Values('D02','Accounting Department')
Insert Into DepartmentD Values('D03','Marketing Department')
Insert Into DepartmentD Values('D04','Human Resource Department')
Insert Into DepartmentD Values('D05','Finance Department')
Insert Into DepartmentD Values('D06','IT Department')
Insert Into DepartmentD Values('D07','Creative Department')
Insert Into DepartmentD Values('D08','Security Department')
Insert Into DepartmentD Values('D09','Customer Service Department')
Insert Into DepartmentD Values('D10','Communication Department')
Insert Into DepartmentD Values('D11','Governance Department')
Insert Into DepartmentD Values('D12','Program Department')
Insert Into DepartmentD Values('D13','Risk Management Department')
Insert Into DepartmentD Values('D14','Customer Service Department')
Insert Into DepartmentD Values('D15','Technology Department')

select*from DepartmentD

Insert Into EmployeeD  Values('D01','E012','Sadaruwan','Sadaruwan@gmail.com','0715648923')
Insert Into EmployeeD  Values('D02','E521','Sahan','Sahan@gmail.com','0775236589')
Insert Into EmployeeD  Values('D03','E623','Chalitha','Chalitha@gmail.com','0712145876')
Insert Into EmployeeD  Values('D04','E052','Otara','Otara@gmail.com','0704856214')
Insert Into EmployeeD  Values('D05','E002','Sampath','Sampath@gmail.com','0777854217')
Insert Into EmployeeD  Values('D06','E015','Lakshan','Lakshan@gmail.com','0715241254')
Insert Into EmployeeD  Values('D07','E152','Sirimewan','Sirimewan@gmail.com','0718562341')
Insert Into EmployeeD  Values('D08','E320','Isuru','Isuru@gmail.com','0717851243')
Insert Into EmployeeD  Values('D09','E624','Kavenga','Kavenga@gmail.com','0752486325')
Insert Into EmployeeD  Values('D10','E112','Janaka','Janaka@gmail.com','0787495222')
Insert Into EmployeeD  Values('D11','E017','Ahinsa','Ahinsa@gmail.com','0765894582')
Insert Into EmployeeD  Values('D12','E051','Saduni','Saduni@gmail.com','0762514785')
Insert Into EmployeeD  Values('D13','E070','Nidulani','Nidulani@gmail.com','0765214820')
Insert Into EmployeeD  Values('D14','E035','Nethmi','Nethmi@gmail.com','0710124253')
Insert Into EmployeeD  Values('D15','E201','Anjali','Anjali@gmail.com','0714580123')

select*from EmployeeD

Insert Into StudentCouncilorD  Values('E012')
Insert Into StudentCouncilorD  Values('E112')
Insert Into StudentCouncilorD  Values('E201')
Insert Into StudentCouncilorD  Values('E051')
Insert Into StudentCouncilorD  Values('E015')

select*from StudentCouncilorD

Insert Into ModuleLeaderD  Values('E623')
Insert Into ModuleLeaderD  Values('E320')
Insert Into ModuleLeaderD  Values('E070')
Insert Into ModuleLeaderD  Values('E052')
Insert Into ModuleLeaderD  Values('E521')

select*from ModuleLeaderD

Insert Into Student_Program_StudentCouncilorD  Values (200044475,01,'E012','S001')
Insert Into Student_Program_StudentCouncilorD  Values (452846252,02,'E512','S002')
Insert Into Student_Program_StudentCouncilorD  Values (561069884,03,'E623','S003')
Insert Into Student_Program_StudentCouncilorD  Values (256546385,04,'E052','S004')
Insert Into Student_Program_StudentCouncilorD  Values (201359865,05,'E002','S005')
Insert Into Student_Program_StudentCouncilorD  Values (889644475,06,'E015','S006')
Insert Into Student_Program_StudentCouncilorD  Values (681235475,07,'E152','S007')
Insert Into Student_Program_StudentCouncilorD  Values (265989896,08,'E320','S008')
Insert Into Student_Program_StudentCouncilorD  Values (892011666,09,'E624','S009')
Insert Into Student_Program_StudentCouncilorD  Values (568963154,10,'E112','S010')
Insert Into Student_Program_StudentCouncilorD  Values (798533457,11,'E017','S011')
Insert Into Student_Program_StudentCouncilorD  Values (895632145,12,'E051','S012')
Insert Into Student_Program_StudentCouncilorD  Values (456683312,13,'E070','S013')
Insert Into Student_Program_StudentCouncilorD  Values (568965647,14,'E035','S014')
Insert Into Student_Program_StudentCouncilorD  Values (568942102,15,'E201','S015')

select*from Student_Program_StudentCouncilorD

Insert Into Student_BatchD  Values (200044475,'B010')
Insert Into Student_BatchD  Values (452846252,'B012')
Insert Into Student_BatchD  Values (561069884,'B014')
Insert Into Student_BatchD  Values (256546385,'B016')
Insert Into Student_BatchD  Values (201359865,'B018')
Insert Into Student_BatchD  Values (889644475,'B020')
Insert Into Student_BatchD  Values (681235475,'B022')
Insert Into Student_BatchD  Values (265989896,'B023')
Insert Into Student_BatchD  Values (892011666,'B024')
Insert Into Student_BatchD  Values (568963154,'B026')
Insert Into Student_BatchD  Values (798533457,'B028')
Insert Into Student_BatchD  Values (895632145,'B030')
Insert Into Student_BatchD  Values (456683312,'B032')
Insert Into Student_BatchD  Values (568965647,'B034')
Insert Into Student_BatchD  Values (568942102,'B036')

select*from Student_BatchD

Insert Into Program_ModuleD Values (1,'M001')
Insert Into Program_ModuleD Values (2,'M002')
Insert Into Program_ModuleD Values (3,'M003')
Insert Into Program_ModuleD Values (4,'M004')
Insert Into Program_ModuleD Values (5,'M005')
Insert Into Program_ModuleD Values (6,'M006')
Insert Into Program_ModuleD Values (7,'M007')
Insert Into Program_ModuleD Values (8,'M008')
Insert Into Program_ModuleD Values (9,'M009')
Insert Into Program_ModuleD Values (10,'M010')
Insert Into Program_ModuleD Values (11,'M011')
Insert Into Program_ModuleD Values (12,'M012')
Insert Into Program_ModuleD Values (13,'M013')
Insert Into Program_ModuleD Values (14,'M014')
Insert Into Program_ModuleD Values (15,'M015')

select*from Program_ModuleD

select*from StudentD
select*from StudentQualificationD
select*from BatchD
select*from ProgramD
select*from DepartmentD
select*from ModuleD
select*from EmployeeD
select*from StudentCouncilorD
select*from ModuleLeaderD
select*from Student_Program_StudentCouncilorD
select*from Student_BatchD
select*from Program_ModuleD


--TASK 07

--List of Student names of a particular Batch
SELECT FName,LName,NIC
FROM StudentD 
where NIC = (
           select NIC
		   from Student_BatchD
		   Where BNo = 'B010')

--List of Batch details and relevant student councilor information
SELECT BNo, StartDate, EndDate, S.ENo
FROM BatchD B JOIN StudentCouncilorD S ON B.ENo = S.ENo;

--List of Program details with relevant modules that they relate to
SELECT P.ProID, P.ProName, M. ModuleNo , M.ModuleName
FROM ProgramD P JOIN Program_ModuleD PM 
ON P.ProID = PM.ProID 
JOIN ModuleD M 
ON PM.ModuleNo = M.ModuleNo;


--TASK 08

--TEST 01 - Testing of primary key 

Insert Into StudentD Values (889644475,'Dulmini','Abayakoon','0768652144','Dulmini@gmail.com','2310','Waththegama')

--TEST 02 - Foreign key

Delete from  EmployeeD where ENo = 'E012'

--TEST 03 - Unique 

Insert Into ModuleD Values('E002','M005','Professional Practice',50,15)

--Test 04 - Not Null

Insert Into StudentD (NIC,LName,PNo ,Email ,PostCode,City) values (123456789,'Peremadasa','0723455896','Suraj@gmail.com','8854','Mathale')

--TEST 05 Testing of data types

Insert Into DepartmentD (DepID,DepartmentName) values ('Customer Service Department','D09')

--TEST 06 Testing of primary key

SELECT * FROM ProgramD WHERE ProID = 09;

--TEST 07 Testing of foreign key

Insert Into ModuleLeaderD (ENo) values ('E123')

--TEST 08 Testing of data types 

Insert Into Student_Program_StudentCouncilorD (NIC,ProID,ENo,ReNo) values (201378765,15,'E016')

--TEST 09 Testing of data types

Insert Into  DepartmentD(DepID,DepartmentName) values ('D16','Distribution Department')

--TEST 10 Testing of primary key 

Insert Into BatchD Values ('E002','B018','2023-04-01','2023-10-01',45)

